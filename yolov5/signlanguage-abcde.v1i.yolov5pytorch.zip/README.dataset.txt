# signlanguage-abcde > 2023-05-16 4:18pm
https://universe.roboflow.com/teste-hvaf8/signlanguage-abcde

Provided by a Roboflow user
License: CC BY 4.0

